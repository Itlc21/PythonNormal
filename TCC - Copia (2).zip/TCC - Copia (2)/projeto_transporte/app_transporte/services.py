import os
import io
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Image
from reportlab.lib.units import inch


def gerar_pdf(minuta):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    # Estilos
    styles = getSampleStyleSheet()
    style_heading = styles['Heading1']
    style_normal = styles['Normal']
    style_center = ParagraphStyle(name='Center', alignment=1)

    # Adicionando o nome da empresa
    nome_empresa = "TR-MACIEL"
    elements.append(Paragraph(nome_empresa, style_heading))
    
    # Adicionando o título "Minuta de Despacho de Carga"
    titulo = "Minuta de Despacho de Carga"
    elements.append(Paragraph(titulo, style_heading))

    # Tabela de Informações
    info_data = [
        ['ID Minuta:', minuta.id],
        ['Veículo:', minuta.veiculo],
        ['Produto:', minuta.produto],
        ['Cliente:', minuta.cliente],
        ['Motorista:', minuta.motorista],
        ['Fatura:', minuta.fatura],
        ['CTE:', minuta.cte],
        ['NF:', minuta.nf],
        ['Observação:', minuta.observacao],
        ['Valor Bruto:', minuta.valor_bruto],
        ['Data da entrega:', minuta.data_trasp],
        ['Prazo de Pag:', minuta.prazo_pag],
        ['Foi entregue?', "Sim" if minuta.entrega else "Não"]  # Convertendo o valor booleano para "Sim" ou "Não"
    ]

    table = Table(info_data, colWidths=[100, 200])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.lightblue),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))

    elements.append(table)

    # Rodapé
    elements.append(Paragraph('Este é um documento gerado automaticamente.', style_center))

    doc.build(elements)
    
    buffer.seek(0)
    return buffer

# Exemplo de uso:
# minuta = ObterMinutaDoBancoDeDados() # Supondo que você tenha uma função para obter a minuta do banco de dados
# pdf_buffer = gerar_pdf(minuta)
# SalvarPDF(pdf_buffer, "minuta.pdf") # Supondo que você tenha uma função para salvar o PDF
