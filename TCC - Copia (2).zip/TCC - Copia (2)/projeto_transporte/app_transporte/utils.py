from datetime import datetime

# Exemplo de data no formato '2024-06-01'
data = '2024-06-01'

# Converter para objeto datetime
data_objeto = datetime.strptime(data, '%Y-%m-%d')

# Formatar para '01/06/2024'
data_formatada = data_objeto.strftime('%d/%m/%Y')

print(data_formatada)  # Saída: '01/06/2024'
