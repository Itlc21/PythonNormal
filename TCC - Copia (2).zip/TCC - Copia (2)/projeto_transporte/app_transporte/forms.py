from django import forms
from .models import Veiculo, Fatura, Motorista, Produto, Cliente, MinutaDespachoCarga
from .utils import datetime

class VeiculoForm(forms.ModelForm):
    class Meta:
        model = Veiculo
        fields = ['marca', 'modelo','placa','renavam','cor']
"""
    marca = models.CharField(max_length=200, default='')
    modelo = models.CharField(max_length=200, default='')
    placa = models.CharField(max_length=200, default='')
    renavam = models.CharField(max_length=200, default='')
    ano = models.IntegerField(default=0)
    cor = models.CharField(max_length=200, default='')
"""
class FaturaForm(forms.ModelForm):
    class Meta:
        model = Fatura
        fields = '__all__'

class MotoristaForm(forms.ModelForm):
    class Meta:
        model = Motorista
        fields = '__all__'

class ProdutoForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = '__all__'

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'

class MinutaDespachoCargaForm(forms.ModelForm):
    class Meta:
        model = MinutaDespachoCarga
        fields = ['veiculo', 'produto', 'cliente', 'motorista', 'fatura', 'cte', 'nf', 'observacao', 'valor_bruto', 'data_trasp', 'prazo_pag', 'entrega']
