from io import BytesIO
from django.db import models
from django.contrib.auth.models import AbstractUser
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from datetime import date
from decimal import Decimal
from .utils import datetime





class CustomUser(AbstractUser):
    cpf = models.CharField(max_length=11, unique=True)

    def __str__(self):
        return self.username

    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        related_query_name='user',
        related_name='custom_user_set',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_query_name='user',
        related_name='custom_user_set',
    )

class Veiculo(models.Model):
    marca = models.CharField(max_length=200, default='')
    modelo = models.CharField(max_length=200, default='')
    placa = models.CharField(max_length=200, default='')
    renavam = models.CharField(max_length=200, default='')
    ano = models.IntegerField(default=0)
    cor = models.CharField(max_length=200, default='')
    excluido = models.BooleanField(default=False)
    status = models.BooleanField(default=True)
    
    def __str__(self):
        return str(self.modelo)
    
class Fatura(models.Model):
    valor_frete = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    vencimento = models.DateField()
    observacao = models.TextField(default='')
    cliente = models.ForeignKey('Cliente', on_delete=models.CASCADE)
    
    def __str__(self):
        return str(self.observacao)
    
class Motorista(models.Model):
    nome = models.CharField(max_length=200, default='')
    cpf = models.CharField(max_length=200, default='')
    cnh = models.CharField(max_length=200, default='')
    endereco = models.CharField(max_length=200, default='')
    telefone = models.CharField(max_length=200, default='')
    email = models.EmailField(default='')
    excluido = models.BooleanField(default=False)
    status = models.BooleanField(default=True)
    
    def __str__(self):
        return str(self.nome)

class Produto(models.Model):
    tipo_produto = models.CharField(max_length=90, default='')
    descricao = models.CharField(max_length=200, default='')
    peso_bruto = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    peso_liquido = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    quantidade = models.IntegerField(default=0)
    especie = models.CharField(max_length=90, default='')
    valor_total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    excluido = models.BooleanField(default=False)
    status = models.BooleanField(default=True)
    
    def __str__(self):
        return str(self.tipo_produto)

class Cliente(models.Model):
    nome_razao_social = models.CharField(max_length=200, default='')
    cpf_cnpj = models.CharField(max_length=20, default='')
    endereco = models.CharField(max_length=200, default='')
    telefone = models.CharField(max_length=200, default='')
    email = models.EmailField(default='')
    excluido = models.BooleanField(default=False)
    status = models.BooleanField(default=True)
    
    def __str__(self):
        return str(f"{self.nome_razao_social} ")

from django.db import models
from datetime import date

class MinutaDespachoCarga(models.Model):
    veiculo = models.ForeignKey('Veiculo', on_delete=models.CASCADE)
    produto = models.ForeignKey('Produto', on_delete=models.CASCADE)
    cliente = models.ForeignKey('Cliente', on_delete=models.CASCADE)
    motorista = models.ForeignKey('Motorista', on_delete=models.CASCADE)
    fatura = models.ForeignKey('Fatura', on_delete=models.CASCADE)
    cte = models.CharField(max_length=200, default='')
    nf = models.CharField(max_length=200, default='')
    observacao = models.TextField(default='')
    valor_bruto = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    data_trasp = models.DateField(default=date.today)
    prazo_pag = models.IntegerField(default=30)
    entrega = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.data_trasp.strftime('%d/%m/%Y')} - {self.cliente} - {self.veiculo}"

    
    
    def gerar_pdf(self):
        # Criar um buffer de bytes para armazenar o PDF
        buffer = BytesIO()

        # Criar um novo canvas para o PDF
        c = canvas.Canvas(buffer, pagesize=letter)

        # Escrever o conteúdo da minuta no PDF
        c.drawString(100, 750, f"Minuta {self.id}")
        c.drawString(100, 730, f"Fatura {self.fatura.id}")
        c.drawString(100, 710, f"Veículo {self.veiculo.modelo}")

        # Finalizar o PDF
        c.showPage()
        c.save()

        # Retornar o buffer de bytes
        return buffer
    
    def __str__(self):
        return f"Minuta {self.id} - Fatura {self.fatura.id} - Veículo {self.veiculo.modelo}"
