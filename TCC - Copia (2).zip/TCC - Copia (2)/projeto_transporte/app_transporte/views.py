from django.http import FileResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from .forms import VeiculoForm, FaturaForm, MotoristaForm, ProdutoForm, ClienteForm, MinutaDespachoCargaForm
from .models import Veiculo, Fatura, Motorista, Produto, Cliente, MinutaDespachoCarga
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
import io
from io import BytesIO
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from .models import CustomUser
from django.db.models import Q
from django.http import HttpResponse
from .services import gerar_pdf
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from .utils import datetime
from datetime import date





def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        cpf = request.POST['cpf']
        try:
            user = CustomUser.objects.create_user(username=username, password=password, cpf=cpf)
            user.save()
            messages.success(request, 'Usuário registrado com sucesso.')
            return redirect('login')  # redireciona para a página de login após o registro bem-sucedido
        except Exception as e:
            messages.error(request, str(e))
    return render(request, 'registration/cad_user.html')



# views.py
def reset_password(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        cpf = request.POST.get('cpf')
        new_password = request.POST.get('new_password')

        try:
            user = CustomUser.objects.get(username=username, cpf=cpf)
            user.set_password(new_password)
            user.save()
            return redirect('login')  # Redirecionar para a página de login após a redefinição de senha
        except CustomUser.DoesNotExist:
            # Handle the case where the user is not found
            return render(request, 'reset_password.html', {'error_message': 'Usuário não encontrado.'})

    return render(request, 'reset_password.html')





"""
se vc quiser bloquear o uso apenas para quem está autenticado
use o decorador @Login_required antes da def de view
Considere usar o objects.POST.get('nome var') para quando quiser alterar apenas uma coluna de algo, tipo lançar produtos
Considere usar o TABELA.objects.all() para puxar todos os objetos de algo
"""

@login_required
def principal(request):
    return render(request, 'principal.html')

@login_required
def index(request):
    return render(request, 'index.html')

# Veículo
def cadastrar_veiculo(request):
    if request.method == 'POST':
        form = VeiculoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Veículo cadastrado com sucesso!')
            return redirect('lista_veiculos')
    else:
        form = VeiculoForm()
    return render(request, 'cadastrar_veiculo.html', {'form': form})

def atualizar_veiculo(request, pk):
    veiculo = get_object_or_404(Veiculo, pk=pk)
    if request.method == 'POST':
        form = VeiculoForm(request.POST, instance=veiculo)
        if form.is_valid():
            
            form.save()
            messages.success(request, 'Veículo atualizado com sucesso!')
            return redirect('lista_veiculos')
    else:
        form = VeiculoForm(instance=veiculo)
    return render(request, 'atualizar_veiculo.html', {'form': form, 'veiculo': veiculo})

def deletar_veiculo(request, pk):
    veiculo = get_object_or_404(Veiculo, pk=pk)
    if request.method == 'POST':
        veiculo.delete()
        messages.success(request, 'Veículo deletado com sucesso!')
        return redirect('lista_veiculos')
    return render(request, 'deletar_veiculo.html', {'veiculo': veiculo})

def lista_veiculos(request):
    veiculos = Veiculo.objects.all()
    return render(request, 'lista_veiculos.html', {'veiculos': veiculos})

def cadastrar_fatura(request):
    if request.method == 'POST':
        form = FaturaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Fatura cadastrada com sucesso!')
            return redirect('lista_faturas')
    else:
        form = FaturaForm()
    clientes = Cliente.objects.all()  # Consulta para obter todos os clientes
    return render(request, 'cadastrar_fatura.html', {'form': form, 'clientes': clientes})  # Passa a lista de clientes para o template

# Restante do código da view...

def atualizar_fatura(request, pk):
    fatura = get_object_or_404(Fatura, pk=pk)
    if request.method == 'POST':
        form = FaturaForm(request.POST, instance=fatura)
        if form.is_valid():
            form.save()
            messages.success(request, 'Fatura atualizada com sucesso!')
            return redirect('lista_faturas')
    else:
        form = FaturaForm(instance=fatura)
    return render(request, 'atualizar_fatura.html', {'form': form, 'fatura': fatura})

def deletar_fatura(request, pk):
    fatura = get_object_or_404(Fatura, pk=pk)
    if request.method == 'POST':
        fatura.delete()
        messages.success(request, 'Fatura deletada com sucesso!')
        return redirect('lista_faturas')
    return render(request, 'deletar_fatura.html', {'fatura': fatura})

def lista_faturas(request):
    faturas = Fatura.objects.all()
    return render(request, 'lista_faturas.html', {'faturas': faturas})

# Motorista
def cadastrar_motorista(request):
    if request.method == 'POST':
        form = MotoristaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Motorista cadastrado com sucesso!')
            return redirect('lista_motoristas')
    else:
        form = MotoristaForm()
    return render(request, 'cadastrar_motorista.html', {'form': form})

def atualizar_motorista(request, pk):
    motorista = get_object_or_404(Motorista, pk=pk)
    if request.method == 'POST':
        form = MotoristaForm(request.POST, instance=motorista)
        if form.is_valid():
            form.save()
            messages.success(request, 'Motorista atualizado com sucesso!')
            return redirect('lista_motoristas')
    else:
        form = MotoristaForm(instance=motorista)
    return render(request, 'atualizar_motorista.html', {'form': form, 'motorista': motorista})

def deletar_motorista(request, pk):
    motorista = get_object_or_404(Motorista, pk=pk)
    if request.method == 'POST':
        motorista.delete()
        messages.success(request, 'Motorista deletado com sucesso!')
        return redirect('lista_motoristas')
    return render(request, 'deletar_motorista.html', {'motorista': motorista})

def lista_motoristas(request):
    motoristas = Motorista.objects.all()
    return render(request, 'lista_motoristas.html', {'motoristas': motoristas})

def cadastrar_produto(request):
    if request.method == 'POST':
        form = ProdutoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Produto cadastrado com sucesso!')
            return redirect('lista_produtos')
    else:
        form = ProdutoForm()
    return render(request, 'cadastrar_produto.html', {'form': form})

def lista_produtos(request):
    produtos = Produto.objects.all()
    return render(request, 'lista_produtos.html', {'produtos': produtos})




def atualizar_produto(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    if request.method == 'POST':
        form = ProdutoForm(request.POST, instance=produto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Produto atualizado com sucesso!')
            return redirect('lista_produtos')
    else:
        form = ProdutoForm(instance=produto)
    return render(request, 'atualizar_produto.html', {'form': form, 'produto': produto})

def deletar_produto(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    if request.method == 'POST':
        produto.delete()
        messages.success(request, 'Produto deletado com sucesso!')
        return redirect('lista_produtos')
    return render(request, 'deletar_produto.html', {'produto': produto})



# Cliente
def cadastrar_cliente(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cliente cadastrado com sucesso!')
            return redirect('lista_clientes')
    else:
        form = ClienteForm()
    return render(request, 'cadastrar_cliente.html', {'form': form})

def atualizar_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    if request.method == 'POST':
        form = ClienteForm(request.POST, instance=cliente)
        if  form.is_valid():
            form.save()
            messages.success(request, 'Cliente atualizado com sucesso!')
            return redirect('lista_clientes')
    else:
        form = ClienteForm(instance=cliente)
    return render(request, 'atualizar_cliente.html', {'form': form, 'cliente': cliente})

def deletar_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    if request.method == 'POST':
        cliente.delete()
        messages.success(request, 'Cliente deletado com sucesso!')
        return redirect('lista_clientes')
    return render(request, 'deletar_cliente.html', {'cliente': cliente})

def lista_clientes(request):
    clientes = Cliente.objects.all()
    return render(request, 'lista_clientes.html', {'clientes': clientes})


def cadastrar_minuta_despacho(request):
    if request.method == 'POST':
        form = MinutaDespachoCargaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Minuta de despacho cadastrada com sucesso!')
            return redirect('lista_minutas_despacho')
    else:
        form = MinutaDespachoCargaForm()
    return render(request, 'cadastrar_minuta_despacho.html', {'form': form})

def atualizar_minuta_despacho(request, pk):
    minuta = get_object_or_404(MinutaDespachoCarga, pk=pk)
    if request.method == 'POST':
        form = MinutaDespachoCargaForm(request.POST, instance=minuta)
        if form.is_valid():
            form.save()
            messages.success(request, 'Minuta de despacho atualizada com sucesso!')
            return redirect('lista_minutas_despacho')
    else:
        form = MinutaDespachoCargaForm(instance=minuta)
    return render(request, 'atualizar_minuta_despacho.html', {'form': form, 'minuta': minuta})

def deletar_minuta_despacho(request, pk):
    minuta = get_object_or_404(MinutaDespachoCarga, pk=pk)
    if request.method == 'POST':
        minuta.delete()
        messages.success(request, 'Minuta de despacho deletada com sucesso!')
        return redirect('lista_minutas_despacho')
    return render(request, 'deletar_minuta_despacho.html', {'minuta': minuta})

def lista_minutas_despacho(request):
    query = request.GET.get('q')
    if query:
        minutas = MinutaDespachoCarga.objects.filter(
            Q(veiculo__placa__icontains=query) |
            Q(produto__descricao__icontains=query) |
            Q(cliente__nome_razao_social__icontains=query) |
            Q(motorista__nome__icontains=query) |
            Q(fatura__observacao__icontains=query) |
            Q(cte__icontains=query) |
            Q(nf__icontains=query) |
            Q(observacao__icontains=query) |
            Q(valor_bruto__icontains=query) |
            Q(data_trasp__icontains=query) |  # Note que para campos de data, você precisa ajustar a entrada para o formato de data correto antes de fazer a consulta
            Q(prazo_pag__icontains=query) |
            Q(entrega__icontains=query)
        )
    else:
        minutas = MinutaDespachoCarga.objects.all()
    
    return render(request, 'lista_minutas_despacho.html', {'minutas': minutas})

def download_pdf(request, minuta_id):
    minuta = get_object_or_404(MinutaDespachoCarga, pk=minuta_id)
    buffer = gerar_pdf(minuta)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="minuta_{minuta_id}.pdf"'
    return response
