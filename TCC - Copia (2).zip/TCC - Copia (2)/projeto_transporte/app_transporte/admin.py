from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Produto)
admin.site.register(Motorista)
admin.site.register(Cliente)
admin.site.register(MinutaDespachoCarga)
admin.site.register(Fatura)
admin.site.register(Veiculo)
