from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from . import views
from .utils import datetime

urlpatterns = [
    path('', views.principal, name='principal'),
    path('index/', views.index, name='index'),
    
    # Motoristas
    path('cadastrar_motorista/', views.cadastrar_motorista, name='cadastrar_motorista'),
    path('lista_motoristas/', views.lista_motoristas, name='lista_motoristas'),
    path('atualizar_motorista/<int:pk>/', views.atualizar_motorista, name='atualizar_motorista'),
    path('deletar_motorista/<int:pk>/', views.deletar_motorista, name='deletar_motorista'),
    

    # Clientes
    path('cadastrar_cliente/', views.cadastrar_cliente, name='cadastrar_cliente'),
    path('lista_clientes/', views.lista_clientes, name='lista_clientes'),
    path('atualizar_cliente/<int:pk>/', views.atualizar_cliente, name='atualizar_cliente'),
    path('deletar_cliente/<int:pk>/', views.deletar_cliente, name='deletar_cliente'),
    

    # Produtos
    path('cadastrar_produto/', views.cadastrar_produto, name='cadastrar_produto'),
    path('lista_produtos/', views.lista_produtos, name='lista_produtos'),
    path('atualizar_produto/<int:pk>/', views.atualizar_produto, name='atualizar_produto'),
    path('deletar_produto/<int:pk>/', views.deletar_produto, name='deletar_produto'),
    

    # Veículos
    path('cadastrar_veiculo/', views.cadastrar_veiculo, name='cadastrar_veiculo'),
    path('lista_veiculos/', views.lista_veiculos, name='lista_veiculos'),
    path('atualizar_veiculo/<int:pk>/', views.atualizar_veiculo, name='atualizar_veiculo'),
    path('deletar_veiculo/<int:pk>/', views.deletar_veiculo, name='deletar_veiculo'),
    

    # Faturas
    path('cadastrar_fatura/', views.cadastrar_fatura, name='cadastrar_fatura'),
    path('lista_faturas/', views.lista_faturas, name='lista_faturas'),
    path('atualizar_fatura/<int:pk>/', views.atualizar_fatura, name='atualizar_fatura'),
    path('deletar_fatura/<int:pk>/', views.deletar_fatura, name='deletar_fatura'),
    

    # Minutas de despacho
    path('cadastrar_minuta_despacho/', views.cadastrar_minuta_despacho, name='cadastrar_minuta_despacho'),
    path('lista_minutas_despacho/', views.lista_minutas_despacho, name='lista_minutas_despacho'),
    path('atualizar_minuta_despacho/<int:pk>/', views.atualizar_minuta_despacho, name='atualizar_minuta_despacho'),
    path('deletar_minuta_despacho/<int:pk>/', views.deletar_minuta_despacho, name='deletar_minuta_despacho'),
    path('download_pdf/<int:minuta_id>/', views.download_pdf, name='download_pdf'),

    # URLs para autenticação
    path('register/', views.register, name='register'),
    path('reset_password/', views.reset_password, name='reset_password'),

    # URLs para administração
    path('accounts/', include('django.contrib.auth.urls')),
]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)